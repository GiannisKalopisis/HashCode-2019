
class Problem:

    def __init__(self, inputPath, outputPath):
        # initialising data
        self.readFile(inputPath)
        
        # initialising results
        self.resDataA = -1
        self.resDataB = -1
        self.resData = [[1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3]]
        self.outputPath = outputPath
        


    def readFile(self, nameFile):
        fl = open(nameFile, "r")

        readLines = fl.readlines()
        firstLine = [int(s) for s in readLines[0].split(' ')]
        self.rows = firstLine[0]
        self.cols = firstLine[1]
        self.dataA = firstLine[2]
        self.dataB = firstLine[2]

        retArray = list()
        for ln in readLines[1:]:
            # retArray.append(map(int, ln.split(' ')))  #Python2.7
            retArray.append([int(s) for s in ln.split(' ')])  # Python 3.6

        self.data = retArray

    def writeFile(self):
        with open(self.outputPath, 'w+') as fl:
            fl.write(str(self.resDataA) + " ")
            fl.write(str(self.resDataB) + "\n")

            for i in range(0, len(self.resData)):
                for j in range(0, len(self.resData[i])):
                    fl.write(str(self.resData[i][j]))
                    if (j != len(self.resData[i]) - 1):
                        fl.write(" ")
                if (i != len(self.resData) - 1):
                    fl.write("\n")



#Problem class initialisation
io = Problem("../input.txt", "../output.txt")


io.writeFile()